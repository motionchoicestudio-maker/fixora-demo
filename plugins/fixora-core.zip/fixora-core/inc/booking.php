<?php
/**
 * Repair request form: block fixora/booking-form or shortcode [fixora_booking_form].
 * Every request is saved under Jobs > Requests (so none is lost if mail fails) and emailed to the site admin (filter `fixora_booking_recipient`).
 * ponytail: no captcha, only a honeypot and a nonce. Swap for a form plugin if a buyer needs more.
 *
 * @package Fixora_Core
 */

defined( 'ABSPATH' ) || exit;

function fixora_core_booking_form() {
	$status = isset( $_GET['fixora_request'] ) ? sanitize_key( wp_unslash( $_GET['fixora_request'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	ob_start();
	if ( 'sent' === $status ) {
		echo '<div class="fx-form-success" role="status"><p class="fx-form-message-text">' . esc_html__( 'Thanks! Your request is in. A technician will call you back within 15 minutes.', 'fixora-core' ) . '</p></div>';
		return ob_get_clean();
	}
	?>
	<form class="fx-booking-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="fixora_request">
		<?php wp_nonce_field( 'fixora_request', 'fixora_request_nonce' ); ?>
		<input type="text" name="fixora_website" tabindex="-1" autocomplete="off" class="fx-hp" aria-hidden="true">
		<div class="fx-form-field">
			<label for="fixora-problem" class="fx-form-label"><?php esc_html_e( 'What needs fixing', 'fixora-core' ); ?></label>
			<input class="fx-form-input" maxlength="256" name="problem" type="text" id="fixora-problem" required>
		</div>
		<div class="fx-form-field">
			<label for="fixora-phone" class="fx-form-label"><?php esc_html_e( 'Your phone', 'fixora-core' ); ?></label>
			<input class="fx-form-input" maxlength="40" name="phone" type="tel" id="fixora-phone" autocomplete="tel" required>
		</div>
		<button type="submit" class="fx-form-submit-button"><?php esc_html_e( 'Get help', 'fixora-core' ); ?></button>
	</form>
	<?php if ( 'error' === $status ) : ?>
		<div class="fx-form-error" role="alert"><p class="fx-form-message-text"><?php esc_html_e( 'Something went wrong while sending your request. Please try again or call us directly.', 'fixora-core' ); ?></p></div>
	<?php endif; ?>
	<?php
	return ob_get_clean();
}
add_shortcode( 'fixora_booking_form', 'fixora_core_booking_form' );

function fixora_core_register_requests() {
	register_post_type(
		'fixora_request',
		array(
			'labels'          => array(
				'name'          => __( 'Requests', 'fixora-core' ),
				'singular_name' => __( 'Request', 'fixora-core' ),
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => 'edit.php?post_type=fixora_job',
			'supports'        => array( 'title', 'editor' ),
			'capability_type' => 'post',
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'    => true,
		)
	);
}
add_action( 'init', 'fixora_core_register_requests' );

function fixora_core_register_blocks() {
	register_block_type( FIXORA_CORE_DIR . 'blocks/booking-form' );
}
add_action( 'init', 'fixora_core_register_blocks' );

function fixora_core_booking_submit() {
	$back = wp_get_referer() ? remove_query_arg( 'fixora_request', wp_get_referer() ) : home_url( '/' );
	$back = strtok( $back, '#' );
	if ( ! isset( $_POST['fixora_request_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['fixora_request_nonce'] ) ), 'fixora_request' ) || ! empty( $_POST['fixora_website'] ) ) {
		wp_safe_redirect( $back );
		exit;
	}
	$problem = isset( $_POST['problem'] ) ? sanitize_text_field( wp_unslash( $_POST['problem'] ) ) : '';
	$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	if ( ! $problem || ! $phone ) {
		wp_safe_redirect( add_query_arg( 'fixora_request', 'error', $back ) . '#book' );
		exit;
	}
	$body  = sprintf( "%s: %s\n%s: %s", __( 'What needs fixing', 'fixora-core' ), $problem, __( 'Phone', 'fixora-core' ), $phone );
	$saved = wp_insert_post(
		array(
			'post_type'    => 'fixora_request',
			'post_status'  => 'private',
			'post_title'   => $problem,
			'post_content' => $body,
		)
	);
	$to = apply_filters( 'fixora_booking_recipient', get_option( 'admin_email' ) );
	/* translators: %s: site name */
	$mailed = wp_mail( $to, sprintf( __( 'New repair request on %s', 'fixora-core' ), get_bloginfo( 'name' ) ), $body );
	wp_safe_redirect( add_query_arg( 'fixora_request', ( $saved || $mailed ) ? 'sent' : 'error', $back ) . '#book' );
	exit;
}
add_action( 'admin_post_nopriv_fixora_request', 'fixora_core_booking_submit' );
add_action( 'admin_post_fixora_request', 'fixora_core_booking_submit' );
