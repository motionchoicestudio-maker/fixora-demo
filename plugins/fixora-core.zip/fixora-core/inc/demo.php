<?php
/**
 * Demo content importer: Appearance > Import Fixora demo. Reads demo/content.json and sideloads demo/img/*.
 * Safe to run again: posts are matched by slug and updated.
 *
 * @package Fixora_Core
 */

defined( 'ABSPATH' ) || exit;

function fixora_core_demo_menu() {
	add_theme_page( __( 'Fixora demo import', 'fixora-core' ), __( 'Import Fixora demo', 'fixora-core' ), 'manage_options', 'fixora-demo', 'fixora_core_demo_page' );
}
add_action( 'admin_menu', 'fixora_core_demo_menu' );

function fixora_core_demo_page() {
	if ( isset( $_POST['fixora_demo_nonce'] ) && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['fixora_demo_nonce'] ) ), 'fixora_demo' ) ) {
		$n = fixora_core_import_demo();
		/* translators: %d: number of imported items */
		printf( '<div class="notice notice-success"><p>%s</p></div>', esc_html( sprintf( __( 'Imported %d items.', 'fixora-core' ), $n ) ) );
	}
	echo '<div class="wrap"><h1>' . esc_html__( 'Import Fixora demo content', 'fixora-core' ) . '</h1><p>' . esc_html__( 'Creates the jobs, blog posts and site pages with demo images, and sets the front page. Safe to run again.', 'fixora-core' ) . '</p><form method="post">';
	wp_nonce_field( 'fixora_demo', 'fixora_demo_nonce' );
	submit_button( __( 'Import demo content', 'fixora-core' ) );
	echo '</form></div>';
}

function fixora_core_demo_image( $basename, $post_id, $alt = '' ) {
	$existing = get_posts( array( 'post_type' => 'attachment', 'numberposts' => 1, 'fields' => 'ids', 'meta_key' => '_fixora_demo_src', 'meta_value' => $basename ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	if ( $existing ) {
		return (int) $existing[0];
	}
	$file = '';
	foreach ( array( 'webp', 'jpg', 'png' ) as $ext ) {
		if ( file_exists( FIXORA_CORE_DIR . 'demo/img/' . $basename . '.' . $ext ) ) {
			$file = FIXORA_CORE_DIR . 'demo/img/' . $basename . '.' . $ext;
			break;
		}
	}
	if ( ! $file ) {
		return 0;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$tmp = wp_tempnam( basename( $file ) );
	copy( $file, $tmp );
	$id = media_handle_sideload( array( 'name' => basename( $file ), 'tmp_name' => $tmp ), $post_id );
	if ( is_wp_error( $id ) ) {
		return 0;
	}
	update_post_meta( $id, '_fixora_demo_src', $basename );
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	return (int) $id;
}

function fixora_core_demo_post( $type, $slug, $title, $content, $extra = array() ) {
	$found = get_posts( array( 'post_type' => $type, 'name' => $slug, 'numberposts' => 1, 'post_status' => 'any', 'fields' => 'ids' ) );
	$args  = array_merge( array( 'post_type' => $type, 'post_name' => $slug, 'post_title' => $title, 'post_content' => $content, 'post_status' => 'publish' ), $extra );
	if ( $found ) {
		$args['ID'] = $found[0];
		return (int) wp_update_post( $args );
	}
	return (int) wp_insert_post( $args );
}

function fixora_core_import_demo() {
	$data = json_decode( (string) file_get_contents( FIXORA_CORE_DIR . 'demo/content.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( ! $data ) {
		return 0;
	}
	// Image sideloading can outlast the default limit on slow hosts.
	if ( function_exists( 'set_time_limit' ) ) {
		set_time_limit( 300 ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged
	}
	// Demo images are shown full size, so skip generating thumbnails: much faster on slow hosts.
	add_filter( 'intermediate_image_sizes_advanced', '__return_empty_array' );
	$n = 0;
	foreach ( $data['jobs'] as $i => $j ) {
		$id = fixora_core_demo_post( 'fixora_job', $j['slug'], $j['title'], '', array( 'post_excerpt' => $j['short'], 'menu_order' => $i ) );
		foreach ( array( 'kicker', 'short', 'price' ) as $k ) {
			update_post_meta( $id, 'fixora_' . $k, $j[ $k ] );
		}
		$img = fixora_core_demo_image( $j['photo'], $id, $j['alt'] );
		if ( $img ) {
			set_post_thumbnail( $id, $img );
		}
		++$n;
	}
	foreach ( $data['posts'] as $p ) {
		$id = fixora_core_demo_post( 'post', $p['slug'], $p['title'], wp_kses_post( $p['body'] ), array( 'post_excerpt' => $p['excerpt'], 'post_date' => $p['date'], 'comment_status' => 'closed' ) );
		wp_set_object_terms( $id, $p['category'], 'category' );
		$img = fixora_core_demo_image( $p['cover'], $id, $p['title'] );
		if ( $img ) {
			set_post_thumbnail( $id, $img );
		}
		++$n;
	}
	foreach ( $data['pages'] as $p ) {
		fixora_core_demo_post( 'page', $p['slug'], $p['title'], wp_kses_post( $p['content'] ) );
		++$n;
	}
	// WordPress sample content would show up in the demo lists.
	foreach ( array( 'hello-world' => 'post', 'sample-page' => 'page' ) as $slug => $type ) {
		$old = get_posts( array( 'post_type' => $type, 'name' => $slug, 'numberposts' => 1, 'post_status' => 'any', 'fields' => 'ids' ) );
		if ( $old ) {
			wp_delete_post( $old[0], true );
		}
	}
	$home = fixora_core_demo_post( 'page', 'home', __( 'Home', 'fixora-core' ), '' );
	$blog = fixora_core_demo_post( 'page', 'blog', __( 'Blog', 'fixora-core' ), '' );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home );
	update_option( 'page_for_posts', $blog );
	update_option( 'posts_per_page', 9 );
	flush_rewrite_rules();
	return $n;
}
