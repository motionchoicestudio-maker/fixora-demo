<?php
/**
 * Jobs post type and its fields. Fields are exposed to blocks through Block Bindings (core/post-meta).
 * ponytail: no custom meta boxes; the fields are edited in the Custom Fields panel. Add a meta box if buyers ask.
 *
 * @package Fixora_Core
 */

defined( 'ABSPATH' ) || exit;

function fixora_core_register_post_types() {
	register_post_type(
		'fixora_job',
		array(
			'labels'       => array(
				'name'          => __( 'Jobs', 'fixora-core' ),
				'singular_name' => __( 'Job', 'fixora-core' ),
				'add_new_item'  => __( 'Add New Job', 'fixora-core' ),
				'edit_item'     => __( 'Edit Job', 'fixora-core' ),
				'all_items'     => __( 'All Jobs', 'fixora-core' ),
			),
			'public'       => true,
			'show_in_rest' => true,
			'has_archive'  => 'jobs',
			'rewrite'      => array( 'slug' => 'jobs', 'with_front' => false ),
			'menu_icon'    => 'dashicons-hammer',
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'page-attributes' ),
		)
	);

	$fields = array(
		'fixora_kicker' => __( 'Category and time, e.g. Plumbing - 40 min', 'fixora-core' ),
		'fixora_short'  => __( 'Short description', 'fixora-core' ),
		'fixora_price'  => __( 'Starting price, e.g. from $49', 'fixora-core' ),
	);
	foreach ( $fields as $key => $label ) {
		register_post_meta(
			'fixora_job',
			$key,
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'label'             => $label,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => function () {
					return current_user_can( 'edit_posts' );
				},
			)
		);
	}
}
add_action( 'init', 'fixora_core_register_post_types' );

/**
 * The jobs archive lists jobs in the order set by the Order field, like the home page list.
 *
 * @param WP_Query $query Main query.
 */
function fixora_core_jobs_order( $query ) {
	if ( ! is_admin() && $query->is_main_query() && $query->is_post_type_archive( 'fixora_job' ) ) {
		$query->set( 'orderby', 'menu_order' );
		$query->set( 'order', 'ASC' );
	}
}
add_action( 'pre_get_posts', 'fixora_core_jobs_order' );
