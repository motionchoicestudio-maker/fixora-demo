<?php
/**
 * Plugin Name: Fixora Core
 * Plugin URI: https://motionchoicestudio-maker.github.io/fixora-demo/
 * Description: Jobs post type, job fields, the repair request form and demo content for the Fixora theme.
 * Version: 1.0.0
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: Promak Design
 * Author URI: https://promak.design
 * License: GPL-2.0-or-later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: fixora-core
 *
 * @package Fixora_Core
 */

defined( 'ABSPATH' ) || exit;

define( 'FIXORA_CORE_VERSION', '1.0.0' );
define( 'FIXORA_CORE_DIR', plugin_dir_path( __FILE__ ) );

require FIXORA_CORE_DIR . 'inc/post-types.php';
require FIXORA_CORE_DIR . 'inc/booking.php';
require FIXORA_CORE_DIR . 'inc/demo.php';

function fixora_core_textdomain() {
	load_plugin_textdomain( 'fixora-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'fixora_core_textdomain', 0 );

register_activation_hook(
	__FILE__,
	function () {
		fixora_core_register_post_types();
		flush_rewrite_rules();
	}
);
