<?php
/**
 * Server render for fixora/booking-form.
 *
 * @package Fixora_Core
 */

defined( 'ABSPATH' ) || exit;

echo fixora_core_booking_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
