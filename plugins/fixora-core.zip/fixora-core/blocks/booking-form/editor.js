( function ( blocks, element, ServerSideRender ) {
	blocks.registerBlockType( 'fixora/booking-form', {
		edit: function () {
			return element.createElement( ServerSideRender, { block: 'fixora/booking-form' } );
		},
		save: function () {
			return null;
		},
	} );
}( window.wp.blocks, window.wp.element, window.wp.serverSideRender ) );
